package org.sudokuapp.sudoku_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
