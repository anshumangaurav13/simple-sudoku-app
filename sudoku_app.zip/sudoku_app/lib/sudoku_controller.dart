import 'dart:convert';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:sudoku_solver_generator/sudoku_solver_generator.dart';

class SudokuController extends GetxController {
  var _currentBoard = <List<int>>[];
  var _emptySpaces = <List<bool>>[];
  var _solvedBoard = <List<int>>[];

  var userBoard = <RxList<int>>[].obs;
  var _selectedTile = <int>[-1, -1].obs;
  var _secondsPassed = 0.obs;

  // var minutesPassed = 0.obs;

  SudokuController(parameters) {
    if (parameters['game'] == 'old') {
      final box = GetStorage();
      print(box.read('currBoard'));
      _currentBoard = box.read('currBoard');
      userBoard = box.read('userBoard');
      _emptySpaces = box.read('emptySpaces');
      _selectedTile = box.read('selectedTile');
      _solvedBoard = box.read('solvedBoard');
      _secondsPassed = box.read('seconds');
    } else if (parameters['game'] == 'new') {
      int diffNum = int.parse(parameters['difficulty']);
      _currentBoard = SudokuGenerator(emptySquares: diffNum).newSudoku;
      _solvedBoard = SudokuSolver.solve(_currentBoard);

      _emptySpaces = List.generate(9, (i) => List.generate(9, (j) => false));
      for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) {
          if (_currentBoard[i][j] == 0) {
            _emptySpaces[i][j] = true;
          }
        }
      }

      userBoard.value = List.generate(9, (i) => RxList.generate(9, (j) => 0));
      for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) {
          userBoard[i][j] = _currentBoard[i][j];
        }
      }
    }
  }

  bool isEmpty(int i, int j) {
    return _emptySpaces[i][j];
  }

  void setSelected(int i, int j) {
    _selectedTile[0] = i;
    _selectedTile[1] = j;
  }

  bool isSelected(int i, int j) {
    return i == _selectedTile[0] && j == _selectedTile[1];
  }

  void insertNumber(int n) {
    var i = _selectedTile[0], j = _selectedTile[1];
    userBoard[i][j] = n;
  }

  bool hasWon() {
    for (int i = 0; i < 9; i++) {
      for (int j = 0; j < 9; j++) {
        if (userBoard[i][j] != _solvedBoard[i][j]) {
          return false;
        }
      }
    }
    return true;
  }

  void tick() {
    if (hasWon()) return;
    _secondsPassed.value++;
  }

  String getTime() {
    var s = _secondsPassed.value;
    var m = s ~/ 60;
    var ms = m < 10 ? "0$m" : m.toString();
    var ss = s < 10 ? "0$s" : s.toString();
    return "$ms:$ss";
  }

  void saveState() {
    final box = GetStorage();
    box.write('currBoard', _currentBoard);
    box.write('userBoard', userBoard);
    box.write('emptySpaces', _emptySpaces);
    box.write('selectedTile', _selectedTile);
    box.write('solvedBoard', _solvedBoard);
    box.write('seconds', _secondsPassed);
  }
}
